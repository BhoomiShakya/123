import React, { useState } from 'react';
import '@fortawesome/fontawesome-free/css/all.min.css';
import './App.css';
import img1 from './assets/img1.png';
import img2 from './assets/img2.png';
import logo from './assets/meridian_logo.png'; 
import { PageLayout } from './components/PageLayout';
import { AuthenticatedTemplate, UnauthenticatedTemplate, useMsal } from '@azure/msal-react';
import Button from 'react-bootstrap/Button';
import { loginRequest } from './authConfig';
import { callMsGraph } from './graph';
import { ProfileData } from './components/ProfileData';
// Import SignInButton and SignOutButton
import { SignInButton } from './components/SignInButton';
import { SignOutButton } from './components/SignOutButton';


const ProfileContent = () => {
  const { instance, accounts } = useMsal();
  const [graphData, setGraphData] = useState(null);

  function RequestProfileData() {
    instance
      .acquireTokenSilent({
        ...loginRequest,
        account: accounts[0],
      })
      .then((response) => {
        callMsGraph(response.accessToken).then((response) => setGraphData(response));
      });
  }

  return (
    <>
      <h5 className="card-title">Welcome {accounts[0].name}</h5>
      {graphData ? (
        <>
          <ProfileData graphData={graphData} />
          <SignOutButton />
        </>
      ) : (
        <Button variant="secondary" onClick={RequestProfileData}>
          Request Profile Information
        </Button>
      )}
    </>
  );
};

function App() {
  const [isSignUpMode, setSignUpMode] = useState(false);

  const handleSignUpClick = () => {
    setSignUpMode(true);
  };

  const handleSignInClick = () => {
    setSignUpMode(false);
  };

  return (
    <PageLayout>
      <div className={`container ${isSignUpMode ? "sign-up-mode" : ""}`}>
        {/* Logo Section */}
        <div className={`logo-container ${isSignUpMode ? "right" : ""}`}>
          <img src={logo} alt="Company Logo" className="company-logo" />
        </div>
        <div className="forms-container">
          <div className="signin-signup">
            {/* Student register */}
            <form action="#" className="sign-in-form">
              <h2 className="title">Student Register</h2>
              <AuthenticatedTemplate>
                <ProfileContent />
              </AuthenticatedTemplate>
              <UnauthenticatedTemplate>
                <h5 className="card-title">Please sign in to register as a student.</h5>
                <SignInButton />
              </UnauthenticatedTemplate>
            </form>
            
            {/* Teacher register */}
            <form action="#" className="sign-up-form">
              <h2 className="title">Teacher Register</h2>
              <AuthenticatedTemplate>
                <ProfileContent />
              </AuthenticatedTemplate>
              <UnauthenticatedTemplate>
                <h5 className="card-title">Please sign in to register as a teacher.</h5>
                <SignInButton />
              </UnauthenticatedTemplate>
            </form>
          </div>
        </div>

        <div className="panels-container">
          <div className="panel left-panel">
            <div className="content">
              <br/><br/>
              <h3>Teacher?</h3>
              <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Debitis, ex ratione. Aliquid!</p>
              <button className="btn transparent teacher-btn" id="sign-up-btn" onClick={handleSignUpClick}>
                Register
              </button>
            </div>
            <img src={img1} className="image" alt="Teacher" />
          </div>
          <div className="panel right-panel">
            <div className="content">
              <br/><br/>
              <h3>Student?</h3>
              <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nostrum laboriosam ad deleniti.</p>
              <button className="btn transparent student-btn" id="sign-in-btn" onClick={handleSignInClick}>
                Register
              </button>
            </div>
            <img src={img2} className="image" alt="Student" />
          </div>
        </div>
      </div>
    </PageLayout>
  );
}

export default App;
