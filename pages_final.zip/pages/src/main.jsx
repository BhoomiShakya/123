import React from 'react';
import ReactDOM from 'react-dom/client'; // Correct import statement
import { PublicClientApplication } from '@azure/msal-browser';
import { MsalProvider } from '@azure/msal-react';
import App from './App';
import { msalConfig } from './authConfig';

const msalInstance = new PublicClientApplication(msalConfig);

const root = ReactDOM.createRoot(document.getElementById('root')); // Use createRoot
root.render(
  <MsalProvider instance={msalInstance}>
    <App />
  </MsalProvider>
);